Compilar con:
gcc -o <nombre del ejecutable> barbero_durmiente.c -lpthread -lm

Ejecutar con:
./<nombre del ejecutable>
